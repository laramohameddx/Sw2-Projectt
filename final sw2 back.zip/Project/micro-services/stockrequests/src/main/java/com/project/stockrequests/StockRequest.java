package com.project.stockrequests;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Table(name="stockrequest")
public class StockRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long supervisorId;
    private Long productId; // Added productId field
    private int quantityChange;
    private String requestStatus;
    private LocalDateTime requestDate;

    // Getters and setters
    // Constructors
}