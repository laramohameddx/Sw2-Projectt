package com.project.stockrequests;

import com.project.supervisor.Supervisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StockRequestService {

    @Autowired
    private StockRequestRepository stockRequestRepository;

    public StockRequest createStockRequest(StockRequest stockRequest) {
        return stockRequestRepository.save(stockRequest);
    }

    public List<StockRequest> getStockRequestsBySupervisorId(Long supervisorId) {
        return stockRequestRepository.findBySupervisorId(supervisorId);
    }
    public List<StockRequest> findAllStockrequest() {
        return stockRequestRepository.findAll();
    }

}