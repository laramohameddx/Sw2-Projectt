package com.project.stockrequests;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:5000")
@RestController
@RequestMapping("/api/stock-requests")
public class StockRequestController {

    @Autowired
    private StockRequestService stockRequestService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void saveStockRequest(@RequestBody StockRequest stockRequest) {
        stockRequestService.createStockRequest(stockRequest);
    }
    @GetMapping("/supervisor/{supervisorId}")
    public ResponseEntity<List<StockRequest>> getStockRequestsForSupervisor(@PathVariable Long supervisorId) {
        List<StockRequest> stockRequests = stockRequestService.getStockRequestsBySupervisorId(supervisorId);
        return new ResponseEntity<>(stockRequests, HttpStatus.OK);
    }
    @GetMapping
    public ResponseEntity<List<StockRequest>> findAllStockrequest() {
        ResponseEntity<List<StockRequest>> ok = ResponseEntity.ok(stockRequestService.findAllStockrequest());
        return ok;
    }
}