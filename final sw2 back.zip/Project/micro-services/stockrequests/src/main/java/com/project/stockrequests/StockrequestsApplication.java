package com.project.stockrequests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockrequestsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockrequestsApplication.class, args);
	}

}
