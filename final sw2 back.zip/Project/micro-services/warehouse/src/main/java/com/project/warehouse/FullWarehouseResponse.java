package com.project.warehouse;

import jakarta.persistence.Entity;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class FullWarehouseResponse {

    private String Name;

    private String Location;

    List<Product> products ;
}
