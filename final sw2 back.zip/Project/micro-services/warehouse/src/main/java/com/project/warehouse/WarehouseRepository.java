package com.project.warehouse;

import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRepository extends JpaRepository<Warehouse, Integer> {
//    List<Product> findAllBySchoolId(Integer schoolId);
}