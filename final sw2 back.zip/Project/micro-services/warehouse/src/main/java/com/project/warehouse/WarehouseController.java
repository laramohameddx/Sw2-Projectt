package com.project.warehouse;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:5000")
@RestController
@RequestMapping("/api/warehouses")

public class WarehouseController {

    private final WarehouseService service;


    public WarehouseController(WarehouseService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void save(
            @RequestBody Warehouse warehouse
    ) {
        service.saveWarehouse (warehouse);
    }

    @GetMapping
    public ResponseEntity<List<Warehouse>> findAllWarehouses() {
        return ResponseEntity.ok(service.findAllWarehouses());
    }


    @GetMapping("/with-products/{warehouse_id}")
    public ResponseEntity<FullWarehouseResponse> findAllWarehouses(
            @PathVariable("warehouse_id") Integer warehouseId
    ) {
        return ResponseEntity.ok(service.findWarehousesWithProducts(warehouseId));
    }


    @PutMapping("/{warehouse_id}")
    public ResponseEntity<Void> updateWarehouse(
            @PathVariable("warehouse_id") Integer warehouseId,
            @RequestBody Warehouse warehouse) {
        service.updateWarehouse(warehouseId, warehouse);
        return ResponseEntity.noContent().build();
    }


    @DeleteMapping("/{warehouse_id}")
    public ResponseEntity<Void> deleteWarehouse(@PathVariable("warehouse_id") Integer warehouseId) {
        service.deleteWarehouse(warehouseId);
        return ResponseEntity.noContent().build();
    }

}
