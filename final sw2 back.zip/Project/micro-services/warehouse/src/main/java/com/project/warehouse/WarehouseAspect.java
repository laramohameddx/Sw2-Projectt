package com.project.warehouse;

import com.project.warehouse.WarehouseNotFoundException;
import com.project.warehouse.WarehouseRepository;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class WarehouseAspect {

    private final WarehouseRepository warehouseRepository;

    @Autowired
    public WarehouseAspect(WarehouseRepository warehouseRepository) {
        this.warehouseRepository = warehouseRepository;
    }

    // Advice to check if warehouse exists in the database
    @Around("execution(* com.project.warehouse.WarehouseService.*(..)) && args(warehouseId,..)")
    public Object checkWarehouseExists(ProceedingJoinPoint joinPoint, Integer warehouseId) throws Throwable {
        if (!warehouseRepository.existsById(warehouseId)) {
            throw new WarehouseNotFoundException("Warehouse not found with id: " + warehouseId);
        }
        return joinPoint.proceed();
    }
}
