package com.project.warehouse;

import jakarta.persistence.Entity;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class Product {

    private String Name;

    private Double Quantity;

}
