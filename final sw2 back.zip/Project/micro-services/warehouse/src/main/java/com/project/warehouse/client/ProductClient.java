package com.project.warehouse.client;

import com.project.warehouse.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "product-service", url = "${application.config.products-url}")
public interface ProductClient {

    @GetMapping("/warehouse/{warehouse-id}")
    List<Product> findAllProductsByWarehouse(@PathVariable("warehouse-id") Integer warehouseId);
}
