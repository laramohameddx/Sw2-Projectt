package com.project.warehouse;

import com.project.warehouse.client.ProductClient;
import lombok.RequiredArgsConstructor;

//import com.project.warehouse.client.StudentClient;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WarehouseService {

    private final WarehouseRepository repository;
    private final ProductClient client;

    public void saveWarehouse(Warehouse warehouse) {
        repository.save(warehouse);
    }

    public List<Warehouse> findAllWarehouses() {
        return repository.findAll();
    }

    public FullWarehouseResponse findWarehousesWithProducts(Integer warehouseId) {

        var warehouse = repository.findById(warehouseId)
                .orElse(
                        Warehouse.builder()
                                .Name("NOT_FOUND")
                                .Location("NOT_FOUND")
                                .build()
                );
        var products = client.findAllProductsByWarehouse(warehouseId);
        return FullWarehouseResponse.builder()
                .Name(warehouse.getName())
                .Location(warehouse.getLocation())
                .products(products)
                .build();
    }


    public void updateWarehouse(Integer warehouseId, Warehouse warehouse) {
        Warehouse existingWarehouse = repository.findById(warehouseId)
                .orElseThrow(() -> new WarehouseNotFoundException("Warehouse not found with id: " + warehouseId));

        // Update the existing warehouse with new data
        existingWarehouse.setName(warehouse.getName());
        existingWarehouse.setLocation(warehouse.getLocation());

        // Save the updated warehouse
        repository.save(existingWarehouse);
    }


    public void deleteWarehouse(Integer warehouseId) {
        repository.deleteById(warehouseId);
    }


//    public List<Product> findAllStudentsBySchool(Integer schoolId) {
//        return repository.findAllBySchoolId(schoolId);
//    }


}
