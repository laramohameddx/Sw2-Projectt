package com.project.product;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor

public class ProductService {

    private final ProductRepository repository;

    public void saveProduct(Product product) {
        repository.save(product);
    }

    public List<Product> findAllProducts() {
        return repository.findAll();
    }

    public List<Product> findAllProductsByWarehouse(Integer warehouseId) {
          return repository.findAllByWarehouseId(warehouseId);

    }

    public void updateProduct(Integer productId, Product product) {
        Product existingProduct = repository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));
        existingProduct.setName(product.getName());
        existingProduct.setQuantity(product.getQuantity());
        existingProduct.setWarehouseId(product.getWarehouseId());
        repository.save(existingProduct);
    }


    public void deleteProduct(Integer productId) {
        Product existingProduct = repository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));
        repository.delete(existingProduct);
    }

//    public List<Product> findAllStudentsBySchool(Integer schoolId) {
//        return repository.findAllBySchoolId(schoolId);
//    }


}
