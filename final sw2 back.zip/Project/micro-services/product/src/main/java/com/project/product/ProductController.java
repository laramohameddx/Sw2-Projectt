package com.project.product;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5000") // Allow requests from localhost:5000 for this method
public class ProductController {

    private final ProductService service;


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void save(
            @RequestBody Product product
    ) {
        service.saveProduct(product);
    }

    @GetMapping
    public ResponseEntity<List<Product>> findAllProducts() {
        return ResponseEntity.ok(service.findAllProducts());
    }


    @GetMapping("/warehouse/{warehouse_id}")
    public ResponseEntity<List<Product>> findAllProducts(
            @PathVariable("warehouse_id") Integer warehouseId
    ) {
        return ResponseEntity.ok(service.findAllProductsByWarehouse(warehouseId));
    }

    @PutMapping("/{product_id}")
    public ResponseEntity<Void> updateProduct(
            @PathVariable("product_id") Integer productId,
            @RequestBody Product product) {
        service.updateProduct(productId, product);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{product_id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("product_id") Integer productId) {
        service.deleteProduct(productId);
        return ResponseEntity.noContent().build();
    }

}
