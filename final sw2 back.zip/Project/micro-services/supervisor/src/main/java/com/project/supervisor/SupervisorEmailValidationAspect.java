package com.project.supervisor;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SupervisorEmailValidationAspect {

    private final supervisorService service;

    @Autowired
    public SupervisorEmailValidationAspect(supervisorService service) {
        this.service = service;
    }

    @Before("execution(* com.project.supervisor.SupervisorController.save(..)) && args(supervisor)")
    public void checkEmailExists(Supervisor supervisor) {
        if (service.findByEmail(supervisor.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email is already in use");
        }
    }
}
