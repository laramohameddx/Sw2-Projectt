package com.project.supervisor;

public class SupervisorNotFoundException extends Throwable {
    public SupervisorNotFoundException(String s) {
    }
}
