package com.project.supervisor;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;


@Service
@RequiredArgsConstructor

public class supervisorService {

        @Autowired
        private final supervisorRepository repository;

        public Supervisor saveSupervisor(Supervisor Supervisor) {
            repository.save(Supervisor);
            return Supervisor;
        }

        public List<Supervisor> findAllSupervisors() {
            return repository.findAll();
        }

        public List<Supervisor> findAllSupervisorByWarehouse(Integer warehouseId) {
            return repository.findAllByWarehouseId(warehouseId);}


        public Optional<Supervisor> findByEmail(String email) {
                return repository.findByEmail(email);
            }

    public Supervisor findById(Integer supervisorId) throws SupervisorNotFoundException {
        Optional<Supervisor> optionalSupervisor = repository.findById(supervisorId);
        return optionalSupervisor.orElseThrow(() -> new SupervisorNotFoundException("Supervisor not found with id: " + supervisorId));
    }



    public Supervisor updateSupervisor(Integer id, Integer warehouseId) {
        Optional<Supervisor> optionalSupervisor = repository.findById(id);
        if (optionalSupervisor.isPresent()) {
            Supervisor existingSupervisor = optionalSupervisor.get();
            // Update existing supervisor's warehouse ID
            existingSupervisor.setWarehouseId(warehouseId);
            // Save the updated supervisor
            return repository.save(existingSupervisor);
        }
        return null; // Return null if supervisor not found
    }


    public void deleteSupervisor(Integer supervisorId) throws SupervisorNotFoundException {
        Optional<Supervisor> optionalSupervisor = repository.findById(supervisorId);
        if (optionalSupervisor.isPresent()) {
            repository.delete(optionalSupervisor.get());
        } else {
            throw new SupervisorNotFoundException("Supervisor not found with id: " + supervisorId);
        }
    }
}
