package com.project.supervisor;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.stream.Collectors;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
@RestController
@RequestMapping("/api/supervisor")
public class SupervisorController {

    private final supervisorService service;

    @Autowired
    public SupervisorController(supervisorService service) {
        this.service = service;
    }



    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @CrossOrigin(origins = "http://localhost:5000")
    public ResponseEntity<Object> save(@Valid @RequestBody Supervisor supervisor, BindingResult bindingResult) {
        // Check if there are validation errors
        if (bindingResult.hasErrors()) {
            List<String> errorMessages = bindingResult.getAllErrors()
                    .stream()
                    .map(error -> {
                        if (error instanceof FieldError) {
                            return error.getDefaultMessage();
                        } else {
                            return error.toString();
                        }
                    })
                    .collect(Collectors.toList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(String.join(", ", errorMessages));
        }

        // Check if the email already exists
        if (service.findByEmail(supervisor.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is already in use");
        }

        // If no validation or existing email errors, save the supervisor
        Supervisor createdSupervisor = service.saveSupervisor(supervisor);
        if (createdSupervisor != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(createdSupervisor);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create supervisor");
        }
    }



    @GetMapping
    @CrossOrigin(origins = "http://localhost:5000")
    public ResponseEntity<List<Supervisor>> findAllSupervisor() {
        return ResponseEntity.ok(service.findAllSupervisors());
    }

    @GetMapping("/warehouse/{warehouse_id}")
    @CrossOrigin(origins = "http://localhost:5000")
    public ResponseEntity<List<Supervisor>> findAllProducts(
            @PathVariable("warehouse_id") Integer warehouseId
    ) {
        return ResponseEntity.ok(service.findAllSupervisorByWarehouse(warehouseId));
    }

    @GetMapping("/super/{email}")
    @CrossOrigin(origins = "http://localhost:5000")
    public Supervisor getByEmail(@PathVariable String email) {
        return service.findByEmail(email).orElse(null);
    }

    @PutMapping("/update/{id}")
    @CrossOrigin(origins = "http://localhost:5000")
    public ResponseEntity<Supervisor> updateSupervisor(
            @PathVariable Integer id,
            @RequestBody UpdateWarehouseRequest request) {
        Supervisor supervisor = service.updateSupervisor(id, request.getWarehouseId());
        if (supervisor != null) {
            return ResponseEntity.ok(supervisor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{supervisor_id}")
    @CrossOrigin(origins = "http://localhost:5000")
    public ResponseEntity<Void> deleteSupervisor(@PathVariable("supervisor_id") Integer supervisorId) {
        try {
            service.deleteSupervisor(supervisorId);
            return ResponseEntity.noContent().build();
        } catch (SupervisorNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
}