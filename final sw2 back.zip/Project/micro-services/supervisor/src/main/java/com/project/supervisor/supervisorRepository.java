package com.project.supervisor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface supervisorRepository extends JpaRepository<Supervisor, Integer> {
        List<Supervisor> findAllByWarehouseId(Integer warehouseId);
        Optional<Supervisor> findByEmail(String email);


}
