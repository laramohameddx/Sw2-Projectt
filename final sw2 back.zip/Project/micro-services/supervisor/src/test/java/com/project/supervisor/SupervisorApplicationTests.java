package com.project.supervisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupervisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
