package com.project.admin;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService service) {
        this.service = service;
    }


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void save(@RequestBody Admin admin) {
        service.saveAdmin(admin);
    }


    @GetMapping("/{email}")
    public Admin getByEmail(@PathVariable String email) {
        Optional<Admin> optionalAdmin = service.findByEmail(email);
        return optionalAdmin.orElse(null); // Return null if supervisor not found
    }

}

