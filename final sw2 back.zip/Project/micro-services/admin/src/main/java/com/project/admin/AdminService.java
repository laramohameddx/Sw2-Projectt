package com.project.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class AdminService {

    private final AdminRepository repository;

    public void saveAdmin(Admin admin) {
        repository.save(admin);
    }

    public Optional<Admin> findByEmail(String email) {
        return repository.findByEmail(email);
    }

}
