package com.project.AuthenticationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthenticationController {

    @Autowired
    private AuthenticationService authenticationService;

    @PostMapping("/api/authenticate")
    @CrossOrigin(origins = "http://localhost:5000") // Allow requests from localhost:5000 for this method
    public ResponseEntity<?> authenticate(@RequestBody LoginRequest loginRequest) {
        Object user = authenticationService.authenticateUser(loginRequest);
        if (user != null) {
            // Authentication successful, return the user object
            return ResponseEntity.ok(user);
        } else {
            // Authentication failed
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication failed");
        }
    }
}
