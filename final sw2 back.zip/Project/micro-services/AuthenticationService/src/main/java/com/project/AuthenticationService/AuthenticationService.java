package com.project.AuthenticationService;

import com.project.AuthenticationService.client.SupervisorClient;
import com.project.AuthenticationService.client.AdminClient;
import com.project.supervisor.Supervisor;
import com.project.admin.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;

@Service
public class AuthenticationService {

    @Autowired
    private SupervisorClient supervisorClient;

    @Autowired
    private AdminClient adminClient;

    public Object authenticateUser(LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        // Make a request to the supervisor microservice to retrieve supervisor by email
        ResponseEntity<Supervisor> supervisorResponse = supervisorClient.getSupervisorByEmail(email);

        if (supervisorResponse.getStatusCode().is2xxSuccessful()) {
            Supervisor supervisor = supervisorResponse.getBody();
            if (supervisor != null && supervisor.getPassword().equals(password)) {
                // Authentication successful for supervisor, return the Supervisor object
                return supervisor;
            }
        }

        // Make a request to the admin microservice to retrieve admin by email
        ResponseEntity<Admin> adminResponse = adminClient.getAdminByEmail(email);

        if (adminResponse.getStatusCode().is2xxSuccessful()) {
            Admin admin = adminResponse.getBody();
            if (admin != null && admin.getPassword().equals(password)) {
                // Authentication successful for admin, return the Admin object
                return admin;
            }
        }

        // Authentication failed, return null
        return null;
    }
}
