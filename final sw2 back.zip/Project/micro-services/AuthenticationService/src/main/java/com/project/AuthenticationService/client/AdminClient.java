package com.project.AuthenticationService.client;

import com.project.supervisor.Supervisor;
import com.project.admin.Admin;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "admin-service", url = "${application.config.admins-url}")
public interface AdminClient {

    @GetMapping("/{email}")
    ResponseEntity<Admin> getAdminByEmail(@PathVariable("email") String email);
}